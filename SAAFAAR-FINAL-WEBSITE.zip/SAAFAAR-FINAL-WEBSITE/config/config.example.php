<?php
return [
 'environment'=>'staging', // production only after the launch checklist is complete
 'base_url'=>'https://saafaar.in',
 'db_dsn'=>'mysql:host=localhost;dbname=YOUR_DATABASE;charset=utf8mb4',
 'db_user'=>'YOUR_DATABASE_USER', 'db_password'=>'',
 'payments_enabled'=>false, 'verified_payee_name'=>'',
 'upi_id'=>'9181628882@pz',
 'approved_terms_version'=>'', // publish approved text in app/policies.php first
 'pricing_rule'=>'', // set to daily_24h ONLY after business approval
 'tax_basis_points'=>0, 'tax_approved'=>false,
 'advance_basis_points'=>0, // explicit approved percentage, 0 disables payment requests
 'email'=>'', 'ga4_id'=>'',
];
