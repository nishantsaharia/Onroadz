const CACHE='saafaar-static-v1';
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(c=>c.addAll(['/offline.html','/assets/css/style.css','/assets/css/brand.css','/favicon.svg'])));self.skipWaiting();});
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(url.origin!==self.location.origin||event.request.method!=='GET')return;
if(event.request.mode==='navigate'){event.respondWith(fetch(event.request).catch(()=>caches.match('/offline.html')));return;}
// Only immutable public styling and icons are eligible. Never cache bookings, APIs or admin responses.
if(['/assets/css/style.css','/assets/css/brand.css','/favicon.svg'].includes(url.pathname))event.respondWith(caches.match(event.request).then(c=>c||fetch(event.request)));
});
