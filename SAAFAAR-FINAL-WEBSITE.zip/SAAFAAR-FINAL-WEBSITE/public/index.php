<?php
// Keep this entry point compatible with older PHP so it can explain a version mismatch.
ini_set('display_errors', '0');
function saafaar_setup_error($message) {
    http_response_code(503);
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Robots-Tag: noindex, nofollow');
    header('X-Content-Type-Options: nosniff');
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Setup needs attention | SAAFAAR</title></head><body><main><h1>Site setup needs attention</h1><p>' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p><p>The hosting administrator can run the temporary hosting-check.php diagnostic and review the server error log. Do not publish credentials.</p></main></body></html>';
    exit;
}
if (PHP_VERSION_ID < 80200) {
    saafaar_setup_error('This website requires PHP 8.2 or newer. Select a supported PHP version for this domain in cPanel.');
}
foreach (array('pdo_mysql', 'mbstring', 'gd', 'session') as $extension) {
    if (!extension_loaded($extension)) {
        saafaar_setup_error('A required PHP extension is missing: ' . $extension . '. Enable it for this domain in cPanel.');
    }
}
$applicationRoot = dirname(__DIR__);
foreach (array('app/front-controller.php', 'app/bootstrap.php', 'app/layout.php', 'app/booking.php', 'app/content.php', 'app/policies.php', 'config/config.example.php') as $requiredFile) {
    if (!is_file($applicationRoot . '/' . $requiredFile) || !is_readable($applicationRoot . '/' . $requiredFile)) {
        saafaar_setup_error('Required private application files are missing or unreadable. Keep app, config and storage beside the public directory, and point the domain document root to public. Do not upload only the contents of public.');
    }
}
if (!is_dir($applicationRoot . '/storage/private') || !is_writable($applicationRoot . '/storage/private')) {
    saafaar_setup_error('Private storage is missing or is not writable by PHP. Restore the storage/private directory and correct its ownership and permissions without making it publicly accessible.');
}
require $applicationRoot . '/app/front-controller.php';
