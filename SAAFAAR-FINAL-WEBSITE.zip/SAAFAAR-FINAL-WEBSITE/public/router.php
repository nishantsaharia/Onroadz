<?php
// Development router. Never serve private project directories.
$p=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
if($p!=='/' && !str_contains($p,'..') && is_file(__DIR__.$p))return false;
require __DIR__.'/index.php';
