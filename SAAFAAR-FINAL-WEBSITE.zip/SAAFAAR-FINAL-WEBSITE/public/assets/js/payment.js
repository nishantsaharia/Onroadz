'use strict';
const target=document.querySelector('#payment-qr');
if(target&&typeof qrcode==='function'){const qr=qrcode(0,'M');qr.addData(target.dataset.upi);qr.make();target.innerHTML=qr.createSvgTag({cellSize:4,margin:4,scalable:true});target.querySelector('svg')?.setAttribute('aria-label','UPI payment request QR code');target.querySelector('svg')?.setAttribute('role','img');}
