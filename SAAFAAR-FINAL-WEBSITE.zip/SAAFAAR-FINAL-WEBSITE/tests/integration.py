"""Run ONLY against an isolated saafaar_test DB and a disposable copy of this project.
Requires PHP_BIN env, TEST_BASE_URL (default http://127.0.0.1:8088), Python 3.
Temporarily enables test-only business gates, restoring configuration in finally.
Never point this at a production instance. Fixtures are intentionally synthetic.
"""
import os, json, subprocess, urllib.request, urllib.parse, urllib.error, http.cookiejar, re, secrets
from pathlib import Path
from datetime import datetime,timedelta,timezone
ROOT=Path(__file__).resolve().parents[1]
PHP=os.environ.get('PHP_BIN','php');BASE=os.environ.get('TEST_BASE_URL','http://127.0.0.1:8088')
passed=[]
def fixture(mode):
 return subprocess.check_output([PHP,str(ROOT/'tests/fixture.php'),mode],text=True)
class Client:
 def __init__(self): self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
 def get(self,path):
  try:
   r=self.opener.open(BASE+path);return r.status,r.read().decode(),dict(r.headers)
  except urllib.error.HTTPError as e:return e.code,e.read().decode(),dict(e.headers)
 def post(self,action,data={},csrf=True):
  payload={'action':action,**data}
  if csrf: payload['csrf']=json.loads(self.get('/api/csrf/')[1])['csrf']
  try:
   r=self.opener.open(BASE+'/action/',urllib.parse.urlencode(payload).encode());return r.status,r.read().decode(),dict(r.headers)
  except urllib.error.HTTPError as e:return e.code,e.read().decode(),dict(e.headers)
def check(name,condition):
 if not condition:raise AssertionError(name)
 passed.append(name);print('PASS',name)
def inspect():return json.loads(fixture('inspect'))
cfg=ROOT/'config/config.php';pol=ROOT/'app/policies.php';saved=cfg.read_text();savedpol=pol.read_text()
try:
 public=Client();check('Homepage renders',public.get('/')[0]==200)
 check('Unknown page is 404',public.get('/missing-page/')[0]==404)
 check('CSRF rejects mutation',public.post('enquiry',{'name':'Test','phone':'9999999999','message':'Test'},False)[0]==403)
 check('Booking blocked without business approvals',public.post('booking',{})[0]==422)
 check('Unauthenticated staff route protected','Staff sign in' in public.get('/admin/')[1])
 check('Private configuration not publicly served',public.get('/config/config.php')[0]==404)
 f=json.loads(fixture('seed'));admin=Client();staff=Client()
 testcfg=saved.replace("'payments_enabled'=>false","'payments_enabled'=>true").replace("'verified_payee_name'=>''","'verified_payee_name'=>'TEST ONLY PAYEE'").replace("'approved_terms_version'=>''","'approved_terms_version'=>'TEST-ONLY-v1'").replace("'pricing_rule'=>''","'pricing_rule'=>'daily_24h'").replace("'tax_approved'=>false","'tax_approved'=>true").replace("'advance_basis_points'=>0","'advance_basis_points'=>2500")
 cfg.write_text(testcfg);pol.write_text("<?php return ['rental-terms'=>'TEST ONLY terms, not business policy.','privacy-policy'=>'TEST ONLY policy.'];")
 check('Owner login',admin.post('admin_login',{'username':f['username'],'password':f['password']})[0]==200)
 check('Staff login',staff.post('admin_login',{'username':f['username']+'_staff','password':f['password']})[0]==200)
 check('Staff cannot change pickup approvals',staff.post('location_save',{'id':1,'fee_paise':0})[0]==403)
 check('Staff cannot export personal records',staff.get('/admin/export/')[0]==403)
 check('SQL injection login rejected',public.post('admin_login',{'username':"' OR 1=1 --",'password':'wrong'})[0]==401)
 check('Approved vehicle visible','Integration vehicle' in public.get('/cars/')[1])
 check('Transmission filter excludes non-matching','Integration vehicle' not in public.get('/cars/?transmission=Manual')[1])
 check('Seven-seat filter matches','Integration vehicle' in public.get('/cars/?seats=7')[1])
 check('Budget filter works','Integration vehicle' not in public.get('/cars/?budget=100')[1])
 check('Array query rejected',public.get('/cars/?model%5B%5D=x')[0]==422)
 start=(datetime.now(timezone(timedelta(hours=5,minutes=30)))+timedelta(days=10)).replace(hour=10,minute=0,second=0,microsecond=0);end=start+timedelta(hours=25)
 data={'vehicle_id':f['vehicle_id'],'pickup_location':1,'return_location':2,'pickup_date':start.strftime('%Y-%m-%d'),'pickup_time':'10:00','return_date':end.strftime('%Y-%m-%d'),'return_time':'11:00'}
 code,body,_=public.get('/api/quote/?'+urllib.parse.urlencode(data));q=json.loads(body)
 check('Server rounds approved 25-hour rental to 2 charging days',code==200 and q['quote']['days']==2)
 check('Server total includes two location fees',q['quote']['total_paise']==620000)
 check('Approved advance calculated in paise',q['quote']['advance_paise']==155000)
 invalid={**data,'return_date':data['pickup_date'],'return_time':'09:00'}
 check('Server rejects inverted dates',public.get('/api/quote/?'+urllib.parse.urlencode(invalid))[0]==422)
 result=public.post('booking',{**data,'name':'<script>alert(1)</script>','phone':'9999999999','email':'','terms':1,'note':'Test route','total_paise':1})
 check('Booking request created',result[0]==200 and 'Your request' in result[1]);check('Customer output escaped','&lt;script&gt;alert(1)&lt;/script&gt;' not in result[1] or '<script>alert(1)</script>' not in result[1])
 token=re.search(r'<code>([a-f0-9]{64})</code>',result[1]).group(1);records=inspect();first=records['bookings'][-1];bid=first['id'];ref=first['reference']
 check('Client price tampering ignored',json.loads(first['quote_json'])['total_paise']==620000)
 check('Request is not confirmed',first['status']=='requested')
 stranger=Client();check('Reference alone does not expose booking',stranger.post('lookup',{'reference':ref,'access_key':'wrong'})[0]==403)
 check('Valid private key permits lookup',stranger.post('lookup',{'reference':ref,'access_key':token})[0]==200)
 check('Access key shown only once','<code>'+token+'</code>' not in public.get('/booking-confirmation/')[1])
 # Pending requests do not reserve inventory; create a competing request.
 other=Client();check('Second request can coexist before confirmation',other.post('booking',{**data,'name':'Other test','phone':'9999999998','terms':1})[0]==200);second=inspect()['bookings'][-1]['id']
 check('Cannot confirm without approved quote',admin.post('confirm',{'booking_id':bid})[0]==422)
 check('Owner approves quote',admin.post('approve_quote',{'booking_id':bid})[0]==200)
 check('Advance payment must be verified first',admin.post('confirm',{'booking_id':bid})[0]==422)
 check('Staff creates payment request',admin.post('payment_request',{'booking_id':bid})[0]==200)
 check('Customer receives UPI request','upi://pay?' in public.get('/booking-confirmation/')[1])
 utr='TEST'+secrets.token_hex(8)
 check('Customer submits UTR',public.post('utr',{'utr':utr})[0]==200)
 check('UTR submission stays pending',inspect()['payments'][0]['status']=='submitted')
 check('Pending UTR cannot confirm booking',admin.post('confirm',{'booking_id':bid})[0]==422)
 check('Staff role cannot verify receipt',staff.post('payment_verify',{'booking_id':bid,'decision':'verified','verification_note':'test','bank_checked':1})[0]==403)
 check('Owner must acknowledge bank verification',admin.post('payment_verify',{'booking_id':bid,'decision':'verified','verification_note':'test'})[0]==422)
 check('Owner records verified receipt',admin.post('payment_verify',{'booking_id':bid,'decision':'verified','verification_note':'Synthetic test only','bank_checked':1})[0]==200)
 check('Verified receipt alone does not confirm',inspect()['bookings'][0]['status']=='quoted')
 check('Owner confirms after verified advance',admin.post('confirm',{'booking_id':bid})[0]==200)
 check('Confirmed booking blocks overlapping quote availability',json.loads(public.get('/api/availability/?'+urllib.parse.urlencode(data))[1])['eligible']==False)
 check('Competing quote can be reviewed',admin.post('approve_quote',{'booking_id':second})[0]==200)
 check('Overlapping confirmation rejected',admin.post('confirm',{'booking_id':second})[0]==409)
 # Blackout outside reservation, then test non-overlap at exact endpoint.
 bstart=start+timedelta(days=6);bend=bstart+timedelta(days=1);block={**data,'pickup_date':bstart.strftime('%Y-%m-%d'),'return_date':bend.strftime('%Y-%m-%d'),'return_time':'10:00','reason':'Synthetic maintenance'}
 check('Owner creates maintenance blackout',admin.post('blackout',block)[0]==200)
 check('Blackout excludes availability',json.loads(public.get('/api/availability/?'+urllib.parse.urlencode(block))[1])['eligible']==False)
 adjacent={**data,'pickup_date':end.strftime('%Y-%m-%d'),'pickup_time':'11:00','return_date':(end+timedelta(days=1)).strftime('%Y-%m-%d'),'return_time':'11:00'}
 check('Adjacent half-open intervals do not overlap',json.loads(public.get('/api/availability/?'+urllib.parse.urlencode(adjacent))[1])['eligible']==True)
 check('Customer cancellation request recorded',public.post('customer_request',{'kind':'cancellation','message':'Synthetic request'})[0]==200)
 check('Cancellation request does not cancel automatically',inspect()['bookings'][0]['status']=='confirmed')
 check('CSV export works',admin.get('/admin/export/')[2].get('Content-Type','').startswith('text/csv'))
 check('Private response is no-store','no-store' in public.get('/booking-confirmation/')[2].get('Cache-Control',''))
 check('Security headers present','Content-Security-Policy' in public.get('/')[2])
 check('Audit log renders',admin.get('/admin/audit/')[0]==200)

 # Exercise owner-controlled discount and upload paths using synthetic assets only.
 expiry=(start+timedelta(days=20)).strftime('%Y-%m-%dT%H:%M')
 check('Owner can create approved promotion',admin.post('promotion_save',{'code':'TEST-DISCOUNT','discount_paise':20000,'minimum_paise':100000,'expires_at':expiry,'active':1})[0]==200)
 discounted=json.loads(public.get('/api/quote/?'+urllib.parse.urlencode({**adjacent,'promo_code':'TEST-DISCOUNT'}))[1])
 check('Approved discount reduces server quote',discounted['quote']['discount_paise']==20000 and discounted['quote']['total_paise']==300000)
 check('Unknown promo is rejected',public.get('/api/quote/?'+urllib.parse.urlencode({**adjacent,'promo_code':'INVALID-CODE'}))[0]==422)
 import struct,zlib
 def chunk(kind,data):return struct.pack('!I',len(data))+kind+data+struct.pack('!I',zlib.crc32(kind+data)&0xffffffff)
 png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',8,8,8,2,0,0,0))+chunk(b'IDAT',zlib.compress((b'\x00'+b'\xff\x00\x00'*8)*8))+chunk(b'IEND',b'')
 def upload(client,content,filename,mime):
  boundary='saafaar'+secrets.token_hex(12);fields={'csrf':json.loads(client.get('/api/csrf/')[1])['csrf'],'action':'upload','vehicle_id':f['vehicle_id'],'alt':'TEST ONLY synthetic red square','sort_order':0};body=b''
  for key,value in fields.items():body+=f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode()
  body+=f'--{boundary}\r\nContent-Disposition: form-data; name="photo"; filename="{filename}"\r\nContent-Type: {mime}\r\n\r\n'.encode()+content+f'\r\n--{boundary}--\r\n'.encode()
  req=urllib.request.Request(BASE+'/action/',body,{'Content-Type':'multipart/form-data; boundary='+boundary})
  try:return client.opener.open(req).status
  except urllib.error.HTTPError as e:return e.code
 check('Disguised executable upload rejected',upload(admin,b'<?php echo "unsafe"; ?>','photo.jpg','image/jpeg')==422)
 check('Staff cannot upload images',upload(staff,png,'test.png','image/png')==403)
 check('Owner image upload re-encodes successfully',upload(admin,png,'test.png','image/png')==200)
 images=inspect()['images'];check('Public derivative is WebP',images[-1]['path'].endswith('.webp') and public.opener.open(BASE+images[-1]['path']).status==200)
 vehicle={'id':f['vehicle_id'],'make':'TEST ONLY','model':'Integration vehicle','slug':'test-only-not-real-inventory','variant':'','model_year':'2025','transmission':'Automatic','fuel':'Petrol','seats':7,'category':'MPV','daily_paise':300000,'deposit_paise':500000,'included_km':150,'extra_km_paise':1200,'minimum_hours':24,'notes':'<b>TEST ONLY safe escaped note</b>','seo_title':'Test vehicle title','seo_description':'Synthetic test listing','active':1,'approved':1,'locations[0]':1,'locations[1]':2}
 check('Owner edits approved listing with mapped photograph',admin.post('vehicle_save',vehicle)[0]==200)
 check('Listing notes are HTML escaped','&lt;b&gt;TEST ONLY safe escaped note&lt;/b&gt;' in public.get('/cars/test-only-not-real-inventory/')[1])
 check('New listing cannot publish without actual photo',admin.post('vehicle_save',{**vehicle,'id':0,'slug':'unphotographed-test-vehicle'})[0]==422)


 for route in ['/admin/','/admin/vehicles/','/admin/vehicles/?edit='+str(f['vehicle_id']),'/admin/locations/','/admin/bookings/','/admin/enquiries/','/admin/promotions/']:
  check('Admin page '+route,admin.get(route)[0]==200)
 fixture('clear_limits');limited=Client();codes=[]
 for _ in range(9):codes.append(limited.post('admin_login',{'username':'not-an-account','password':'wrong'})[0])
 check('Login throttling returns 429',codes[-1]==429)
 print(json.dumps({'passed':len(passed),'failed':0}))
finally:
 cfg.write_text(saved);pol.write_text(savedpol)
