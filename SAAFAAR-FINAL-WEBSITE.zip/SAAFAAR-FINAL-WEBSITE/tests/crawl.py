import urllib.request,urllib.parse,urllib.error,json
from html.parser import HTMLParser
from collections import deque
from pathlib import Path
import os
BASE=os.environ.get('TEST_BASE_URL','http://127.0.0.1:8088')
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.canonical=[];self.h1=0
 def handle_starttag(self,t,a):
  a=dict(a)
  if t in ['a','link'] and a.get('href','').startswith('/'):self.links.append(a['href'])
  if t in ['img','script'] and a.get('src','').startswith('/'):self.links.append(a['src'])
  if t=='link' and a.get('rel')=='canonical':self.canonical.append(a['href'])
  if t=='h1':self.h1+=1
queue=deque(['/']);seen=set();failed=[];html=0
while queue:
 path=queue.popleft().split('#')[0]
 if path in seen:continue
 seen.add(path)
 try:
  r=urllib.request.urlopen(BASE+path);data=r.read();typ=r.headers.get('Content-Type','')
  if 'text/html' in typ:
   html+=1;p=Parser();p.feed(data.decode());assert len(p.canonical)==1,(path,'canonical count')
   assert p.h1==1,(path,'H1 count',p.h1)
   for link in p.links:
    if not link.startswith('/admin/export') and link not in seen:queue.append(link)
 except Exception as e:failed.append((path,str(e)))
print(json.dumps({'resources_checked':len(seen),'html_pages_checked':html,'failures':failed},indent=2));assert not failed

