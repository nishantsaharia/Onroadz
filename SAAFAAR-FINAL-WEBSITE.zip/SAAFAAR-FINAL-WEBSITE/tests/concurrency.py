import os,subprocess,json
from pathlib import Path
root=Path(__file__).resolve().parent;php=os.environ.get('PHP_BIN','php')
ids=json.loads(subprocess.check_output([php,str(root/'concurrency.php'),'seed']))
workers=[subprocess.Popen([php,str(root/'concurrency.php'),'confirm',str(i)],stdout=subprocess.PIPE,stderr=subprocess.PIPE) for i in ids]
for p in workers:p.communicate(timeout=20)
count=int(subprocess.check_output([php,str(root/'concurrency.php'),'count']))
assert count==1, f'Expected exactly one confirmation; got {count}'
print('PASS concurrent overlapping confirmations: exactly one committed')
