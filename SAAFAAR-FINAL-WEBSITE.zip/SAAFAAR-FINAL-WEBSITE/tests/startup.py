"""Exercise actual HTTP startup under incomplete hosting layouts.
Use PHP_BIN for a PHP 8.2+ executable with required extensions. Optionally set
PHP_MINIMAL_BIN to a PHP executable started with -n to test missing extensions.
No production database or credentials are used. Temporary servers are stopped.
"""
from pathlib import Path
import os,shutil,socket,subprocess,tempfile,time,urllib.request,urllib.error
SOURCE=Path(__file__).resolve().parents[1]
PHP=os.environ.get('PHP_BIN','php')
passed=[]
def check(label,ok):
    assert ok,label
    passed.append(label)
    print('PASS',label)
def copy_project(target):
    for item in SOURCE.rglob('*'):
        if not item.is_file():continue
        rel=item.relative_to(SOURCE).as_posix()
        if rel=='config/config.php' or '__pycache__' in item.parts or rel.startswith('storage/private/') or rel.startswith('storage/logs/') or (rel.startswith('public/uploads/') and not rel.endswith('/.htaccess')):continue
        out=target/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(item,out)
    (target/'storage/private').mkdir(parents=True,exist_ok=True)
    (target/'storage/logs').mkdir(parents=True,exist_ok=True)
def get(port,path):
    try:
        with urllib.request.urlopen('http://127.0.0.1:'+str(port)+path,timeout=2) as response:return response.status,response.read().decode(),dict(response.headers)
    except urllib.error.HTTPError as error:return error.code,error.read().decode(),dict(error.headers)
def run(root,assertions,minimal=False):
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    command=([os.environ['PHP_MINIMAL_BIN'],'-n'] if minimal else [PHP])+['-S','127.0.0.1:'+str(port),'-t',str(root/'public'),str(root/'public/router.php')]
    process=subprocess.Popen(command,cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        for _ in range(80):
            if process.poll() is not None:raise RuntimeError('Temporary PHP server could not start')
            try:get(port,'/hosting-check.php');break
            except (OSError,urllib.error.URLError):time.sleep(.05)
        else:raise RuntimeError('Temporary PHP server did not become ready')
        assertions(port)
    finally:
        process.terminate()
        try:process.wait(timeout=5)
        except subprocess.TimeoutExpired:process.kill();process.wait()
with tempfile.TemporaryDirectory(prefix='saafaar-startup-') as temporary:
    healthy=Path(temporary)/'healthy';copy_project(healthy)
    def healthy_checks(port):
        status,body,_=get(port,'/');check('Complete default package renders homepage without private runtime config',status==200 and 'Go somewhere' in body)
        status,body,headers=get(port,'/hosting-check.php');check('Standalone diagnostic renders without loading DB credentials',status==200 and 'SAAFAAR hosting checks' in body)
        check('Diagnostic is noindex and no-store','noindex' in headers.get('X-Robots-Tag','') and 'no-store' in headers.get('Cache-Control',''))
        check('Diagnostic does not expose temporary filesystem paths',str(healthy) not in body)
    run(healthy,healthy_checks)
    missing=Path(temporary)/'public-only';(missing/'public').mkdir(parents=True);shutil.copytree(healthy/'public',missing/'public',dirs_exist_ok=True)
    def missing_checks(port):
        status,body,_=get(port,'/');check('Public-only upload returns actionable setup 503',status==503 and 'Required private application files' in body)
        status,body,_=get(port,'/hosting-check.php');check('Diagnostic survives missing private application',status==200 and 'FAIL' in body)
    run(missing,missing_checks)
    readonly=Path(temporary)/'readonly';copy_project(readonly);(readonly/'storage/private').chmod(0o555)
    try:run(readonly,lambda port:check('Unwritable private storage returns actionable setup 503',get(port,'/')[0]==503 and 'Private storage' in get(port,'/')[1]))
    finally:(readonly/'storage/private').chmod(0o755)
    broken=Path(temporary)/'broken-config';copy_project(broken);(broken/'config/config.php').write_text("<?php return ['password'=>'SENTINEL-DO-NOT-DISPLAY',")
    def broken_checks(port):
        status,body,_=get(port,'/');check('Malformed config is handled without displaying credentials',status==500 and 'We could not complete' in body and 'SENTINEL-DO-NOT-DISPLAY' not in body)
        check('Diagnostic works despite malformed config',get(port,'/hosting-check.php')[0]==200)
    run(broken,broken_checks)
    blocked=Path(temporary)/'blocked-session';copy_project(blocked);(blocked/'storage/private/sessions').write_text('not a directory')
    run(blocked,lambda port:check('Session creation exception is handled safely',get(port,'/')[0]==500 and 'We could not complete' in get(port,'/')[1]))
    if os.environ.get('PHP_MINIMAL_BIN'):
        run(healthy,lambda port:check('Missing required extension returns actionable setup 503',get(port,'/')[0]==503 and 'required PHP extension' in get(port,'/')[1]),minimal=True)
print(str(len(passed))+' startup checks passed')
