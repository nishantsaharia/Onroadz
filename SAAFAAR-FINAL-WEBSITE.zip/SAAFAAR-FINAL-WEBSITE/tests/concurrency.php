<?php
if(PHP_SAPI!=='cli')exit(1);
require dirname(__DIR__).'/app/bootstrap.php';
if(!str_contains($cfg['db_dsn'],'saafaar_test'))throw new RuntimeException('Only isolated test DB permitted.');
if(($argv[1]??'')==='seed'){
 $vehicle=(int)sql("SELECT id FROM vehicles WHERE slug='test-only-not-real-inventory'")->fetchColumn();
 $ids=[];for($i=0;$i<2;$i++){sql("INSERT INTO bookings(reference,vehicle_id,customer_name,phone,pickup_location_id,return_location_id,starts_at,ends_at,token_hash,token_expires_at,terms_version,quote_json,quote_approved,status) VALUES(?,?,'Concurrency test','9999999999',1,2,DATE_ADD(NOW(),INTERVAL 40 DAY),DATE_ADD(NOW(),INTERVAL 42 DAY),?,DATE_ADD(NOW(),INTERVAL 80 DAY),'TEST','{\"total_paise\":100,\"advance_paise\":0}',1,'quoted')",['SF-RACE-'.bin2hex(random_bytes(6)),$vehicle,hash('sha256',random_bytes(32))]);$ids[]=(int)db()->lastInsertId();}echo json_encode($ids);
}elseif(($argv[1]??'')==='confirm'){$_SESSION['admin']=['id'=>(int)sql("SELECT id FROM administrators WHERE role='owner' LIMIT 1")->fetchColumn()];confirm_booking((int)$argv[2]);echo 'confirmed';}
elseif(($argv[1]??'')==='count'){echo sql("SELECT COUNT(*) FROM bookings WHERE reference LIKE 'SF-RACE-%' AND status='confirmed'")->fetchColumn();}
