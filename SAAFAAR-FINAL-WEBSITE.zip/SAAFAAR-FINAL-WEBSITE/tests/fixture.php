<?php
if(PHP_SAPI!=='cli')exit(1);
require dirname(__DIR__).'/app/bootstrap.php';
if(!str_contains($cfg['db_dsn'],'saafaar_test'))throw new RuntimeException('Tests require an isolated database named saafaar_test.');
$mode=$argv[1]??'';
if($mode==='seed'){
 $username='test_'.bin2hex(random_bytes(4));$password=bin2hex(random_bytes(24));sql("INSERT INTO administrators(username,password_hash,role) VALUES(?,?,'owner')",[$username,password_hash($password,PASSWORD_DEFAULT)]);$owner=(int)db()->lastInsertId();sql("INSERT INTO administrators(username,password_hash,role) VALUES(?,?,'staff')",[$username.'_staff',password_hash($password,PASSWORD_DEFAULT)]);
 sql("INSERT INTO vehicles(slug,make,model,model_year,transmission,fuel,seats,category,daily_paise,deposit_paise,included_km,extra_km_paise,minimum_hours,notes,active,approved) VALUES('test-only-not-real-inventory','TEST ONLY','Integration vehicle',2025,'Automatic','Petrol',7,'MPV',300000,500000,150,1200,24,'Temporary synthetic test fixture. Not SAAFAAR inventory.',1,1)");$vehicle=(int)db()->lastInsertId();sql('UPDATE pickup_locations SET active=1,fee_paise=10000');foreach(sql('SELECT id FROM pickup_locations')->fetchAll() as $l)sql('INSERT INTO vehicle_locations VALUES(?,?)',[$vehicle,$l['id']]);
 echo json_encode(['username'=>$username,'password'=>$password,'vehicle_id'=>$vehicle,'owner_id'=>$owner]);
}elseif($mode==='inspect'){echo json_encode(['bookings'=>sql('SELECT id,reference,status,quote_approved,quote_json FROM bookings ORDER BY id')->fetchAll(),'payments'=>sql('SELECT booking_id,status,utr FROM payment_requests')->fetchAll(),'images'=>sql('SELECT * FROM vehicle_images')->fetchAll()]);}
elseif($mode==='clear_limits'){sql('DELETE FROM rate_limits');}
