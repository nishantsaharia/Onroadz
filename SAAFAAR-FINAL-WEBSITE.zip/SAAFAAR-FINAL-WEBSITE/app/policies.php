<?php
return []; // Add approved policy text keyed by rental-terms, cancellation-refund-policy, privacy-policy. Never invent contractual rules.
