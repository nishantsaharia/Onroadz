<?php
return json_decode(<<<'JSON'
{
  "self-drive-car-rental-guwahati": {
    "title": "Self-drive car rental in Guwahati",
    "kicker": "YOUR JOURNEY STARTS HERE",
    "intro": "Plan a city journey or a Northeast road trip with SAAFAAR HOLIDAYS. Tell us where you want to go, when you need a car and how many people are travelling.",
    "sections": {
      "Choose a car around your journey": "An automatic can make city driving more comfortable. A compact car is easier to place in tight streets, while a larger SUV or MPV may suit a family with luggage. Confirm the actual vehicle, luggage space and route permission before committing.",
      "A quotation you can review": "An enquiry is not a reservation. We check the requested dates, vehicle, pickup arrangements and proposed route before staff approval. Review the agreed rate, deposit, kilometre allowance, extra charges and cancellation terms in writing.",
      "Collecting your car": "Share your pickup and return times in Indian Standard Time. Tell us about any train or flight connection and leave time for vehicle inspection, document checks and handover. A pickup request remains subject to confirmation."
    },
    "kind": "commercial"
  },
  "guwahati-airport-car-rental": {
    "title": "Guwahati Airport car rental",
    "kicker": "ARRIVE. COLLECT. EXPLORE.",
    "intro": "Request a self-drive car handover at airport. Pickup service, timing and any delivery fees are subject to staff confirmation.",
    "sections": {
      "Plan the handover": "Share your flight number, scheduled arrival and a contact number reachable after landing. Agree a specific handover point with staff; do not assume a car will be waiting at the terminal. Allow for baggage collection, flight delays and the return inspection before check-in.",
      "Choose a suitable vehicle": "Tell us your group size, luggage and onward route. Check the actual vehicle details and written route approval. Availability changes with the selected dates; only an approved booking reserves a vehicle.",
      "Before your return": "Agree the return location, fuel requirement, inspection procedure and timing with staff. Request the full rental and cancellation terms before accepting a quote."
    },
    "kind": "commercial"
  },
  "guwahati-railway-station-car-rental": {
    "title": "Guwahati Railway Station car rental",
    "kicker": "ARRIVE. COLLECT. EXPLORE.",
    "intro": "Request a self-drive car handover at Guwahati Railway Station. Pickup service, timing and any delivery fees are subject to staff confirmation.",
    "sections": {
      "Plan the handover": "Share your train number, arrival time and luggage requirements. Agree the station exit and a reachable meeting point before travelling. Delivery, waiting time and return arrangements need to be confirmed in the quotation.",
      "Choose a suitable vehicle": "Tell us your group size, luggage and onward route. Check the actual vehicle details and written route approval. Availability changes with the selected dates; only an approved booking reserves a vehicle.",
      "Before your return": "Agree the return location, fuel requirement, inspection procedure and timing with staff. Request the full rental and cancellation terms before accepting a quote."
    },
    "kind": "commercial"
  },
  "kamakhya-railway-station-car-rental": {
    "title": "Kamakhya Railway Station car rental",
    "kicker": "ARRIVE. COLLECT. EXPLORE.",
    "intro": "Request a self-drive car handover at Kamakhya Railway Station. Pickup service, timing and any delivery fees are subject to staff confirmation.",
    "sections": {
      "Plan the handover": "Kamakhya and Guwahati Railway Station are separate pickup requests. State the correct station and train number. Leave time to find your agreed meeting point and inspect the vehicle before starting your journey.",
      "Choose a suitable vehicle": "Tell us your group size, luggage and onward route. Check the actual vehicle details and written route approval. Availability changes with the selected dates; only an approved booking reserves a vehicle.",
      "Before your return": "Agree the return location, fuel requirement, inspection procedure and timing with staff. Request the full rental and cancellation terms before accepting a quote."
    },
    "kind": "commercial"
  },
  "automatic-car-rental-guwahati": {
    "title": "Automatic car rental in Guwahati",
    "kicker": "FIND YOUR KIND OF DRIVE",
    "intro": "For drivers who prefer fewer gear changes in traffic, compare approved automatic vehicles. Familiarise yourself with the selector, parking brake and hill-driving controls before departure.",
    "sections": {
      "Compare verified details": "Use the catalogue to review approved transmission, seating, fuel type and photographs. No model or price is offered for booking until its listing is approved.",
      "Dates make the difference": "Enter pickup and return dates to check reservations and maintenance blocks on the server. Results show eligible vehicles for those dates, subject to staff review of your journey.",
      "Know your quotation": "Ask for the rental duration rule, included kilometres, extra-kilometre charge, deposit, taxes and pickup charges. Review cancellation and driver eligibility terms before accepting."
    },
    "kind": "category"
  },
  "suv-rental-guwahati": {
    "title": "SUV rental in Guwahati",
    "kicker": "FIND YOUR KIND OF DRIVE",
    "intro": "Choose an SUV around passenger comfort, luggage and the approved route. An SUV badge does not establish four-wheel drive or permission to enter difficult or restricted roads.",
    "sections": {
      "Compare verified details": "Use the catalogue to review approved transmission, seating, fuel type and photographs. No model or price is offered for booking until its listing is approved.",
      "Dates make the difference": "Enter pickup and return dates to check reservations and maintenance blocks on the server. Results show eligible vehicles for those dates, subject to staff review of your journey.",
      "Know your quotation": "Ask for the rental duration rule, included kilometres, extra-kilometre charge, deposit, taxes and pickup charges. Review cancellation and driver eligibility terms before accepting."
    },
    "kind": "category"
  },
  "seven-seater-car-rental-guwahati": {
    "title": "Seven-seater car rental in Guwahati",
    "kicker": "FIND YOUR KIND OF DRIVE",
    "intro": "Plan passenger space and baggage together. Seven occupied seats can leave limited luggage room. Ask for photographs of the actual seating and luggage arrangement.",
    "sections": {
      "Compare verified details": "Use the catalogue to review approved transmission, seating, fuel type and photographs. No model or price is offered for booking until its listing is approved.",
      "Dates make the difference": "Enter pickup and return dates to check reservations and maintenance blocks on the server. Results show eligible vehicles for those dates, subject to staff review of your journey.",
      "Know your quotation": "Ask for the rental duration rule, included kilometres, extra-kilometre charge, deposit, taxes and pickup charges. Review cancellation and driver eligibility terms before accepting."
    },
    "kind": "category"
  },
  "hatchback-rental-guwahati": {
    "title": "Hatchback rental in Guwahati",
    "kicker": "FIND YOUR KIND OF DRIVE",
    "intro": "A hatchback can suit a smaller group travelling light. Compare actual boot space, transmission and the intended itinerary before requesting a quote.",
    "sections": {
      "Compare verified details": "Use the catalogue to review approved transmission, seating, fuel type and photographs. No model or price is offered for booking until its listing is approved.",
      "Dates make the difference": "Enter pickup and return dates to check reservations and maintenance blocks on the server. Results show eligible vehicles for those dates, subject to staff review of your journey.",
      "Know your quotation": "Ask for the rental duration rule, included kilometres, extra-kilometre charge, deposit, taxes and pickup charges. Review cancellation and driver eligibility terms before accepting."
    },
    "kind": "category"
  },
  "sedan-car-rental-guwahati": {
    "title": "Sedan car rental in Guwahati",
    "kicker": "FIND YOUR KIND OF DRIVE",
    "intro": "For city travel and road trips on suitable routes, consider a sedan with the comfort and luggage space your group needs. Confirm road suitability with staff.",
    "sections": {
      "Compare verified details": "Use the catalogue to review approved transmission, seating, fuel type and photographs. No model or price is offered for booking until its listing is approved.",
      "Dates make the difference": "Enter pickup and return dates to check reservations and maintenance blocks on the server. Results show eligible vehicles for those dates, subject to staff review of your journey.",
      "Know your quotation": "Ask for the rental duration rule, included kilometres, extra-kilometre charge, deposit, taxes and pickup charges. Review cancellation and driver eligibility terms before accepting."
    },
    "kind": "category"
  },
  "northeast-india": {
    "title": "Northeast India, at your own pace",
    "kicker": "THE ROAD IS PART OF THE DESTINATION",
    "intro": "From Assam’s river city to Meghalaya’s highlands and the mountain journeys of Arunachal Pradesh, build a trip with room to stop and change your pace.",
    "sections": {
      "Start with a realistic route": "Choose one region well rather than filling every day with a long transfer. Allow daylight for unfamiliar roads, an arrival buffer and rest days. Confirm the route with SAAFAAR before hiring a vehicle.",
      "Plan for changing conditions": "Mountain weather, road works and local restrictions can change an itinerary. Check official state tourism and district notices close to departure, book flexible stays where possible and keep an alternative plan.",
      "Travel thoughtfully": "Ask before photographing people, respect local guidance and take waste back to an appropriate disposal point. Follow forest and village access rules and use local guides where required.",
      "Begin with Assam": "Spend time in Guwahati before a longer journey if it fits your arrival. For Kaziranga, confirm park-season notices, accommodation and authorized visitor activities directly with official sources or approved operators. A rental vehicle does not replace regulated park transport or entry arrangements.",
      "Make room for culture": "For a Hornbill Festival visit, confirm the current official programme, stay arrangements near Kohima and local transfers toward Kisama. Travel permissions and rental route approval need their own checks; festival attendance does not automatically establish either.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "meghalaya-self-drive-car-rental": {
    "title": "Meghalaya road trips",
    "kicker": "CLOUD COUNTRY",
    "intro": "Use Guwahati as a starting point for a Meghalaya itinerary shaped around Shillong, Umiam Lake, Sohra and the river destinations near Dawki.",
    "sections": {
      "Shape your route": "Guwahati → Umiam → Shillong. From Shillong, choose a Sohra loop or a separate Dawki and Shnongpdeng leg rather than rushing both.",
      "Conditions, permissions and limitations": "Rain and mist can reduce visibility. Waterfalls, river activities and trails have conditions that change with weather. Verify local access before setting off.",
      "Build a flexible itinerary": "Leave dedicated time for Sohra viewpoints. Nongriat and the Double Decker Living Root Bridge involve a walking journey, not a drive-up stop; check trail advice and your fitness before going.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Choose your stops, not just a pin list": "Shillong and Umiam can anchor an arrival day. Sohra is a separate base for landscape stops and walking plans. Dawki, the Umngot River and Shnongpdeng need their own timing and locally confirmed river activity arrangements. Mawlynnong, Laitlum Canyon and Krang Suri Falls should be selected around your overnight route rather than added as guaranteed drive-through stops.",
      "Walking days and overnight stays": "Nongriat and the Double Decker Living Root Bridge require a walking plan, suitable footwear, a realistic fitness assessment and current local trail advice. Confirm accommodation, parking and check-in arrangements before leaving a vehicle for a walking excursion.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "arunachal-pradesh-road-trip": {
    "title": "Arunachal Pradesh road-trip planning",
    "kicker": "BEYOND THE FAMILIAR",
    "intro": "Arunachal journeys need time, current permission checks and flexibility. The western Tawang route, Anini and Mechuka are separate itineraries with very different logistics.",
    "sections": {
      "Shape your route": "For a western itinerary, discuss a route through the foothills toward Bomdila, Dirang and Tawang. Choose overnight stops around current conditions and your driving experience.",
      "Conditions, permissions and limitations": "Check current Arunachal entry-permit rules for your nationality and travel purpose. Additional local permissions may apply. Rental-car route approval is separate from a visitor permit.",
      "Build a flexible itinerary": "Plan overnight stops before high mountain sections. Shergaon, Sangti Valley and Zemithang should be considered as deliberate extensions, with current access checked locally.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Western Arunachal stops": "Bomdila and Dirang can be considered as overnight bases on a western itinerary. Sangti Valley, Shergaon and Zemithang deserve deliberate planning rather than a rushed checklist. Confirm local roads, weather and vehicle permission for each deviation before departure.",
      "Separate eastern and central journeys": "Anini and Mechuka are not presented as day-trip extensions of Tawang. Choose a region, consult experienced local operators and verify the complete approach, accommodation and permissions. Do not combine distant regions merely to fill a short holiday.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "tawang-self-drive-car-rental": {
    "title": "Tawang travel and vehicle enquiries",
    "kicker": "A JOURNEY INTO THE HIGH HIMALAYA",
    "intro": "Tawang is a mountain journey to plan carefully, with time for the approach, rest and local exploration. Confirm route approval and current travel advice before hiring.",
    "sections": {
      "Shape your route": "Discuss Guwahati → Bomdila → Dirang → Tawang with your rental team. Overnight stops should reflect daylight, weather, road conditions and your comfort at altitude.",
      "Conditions, permissions and limitations": "Do not assume a Guwahati self-drive rental can access every local excursion. Bumla and other restricted areas require current local guidance and may require permitted local transport.",
      "Build a flexible itinerary": "Build a spare day into the plan. Ask accommodation providers about current approach conditions and consider advice on altitude and health from a qualified professional.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "guwahati-to-tawang-road-trip": {
    "title": "Guwahati to Tawang: plan the journey",
    "kicker": "SLOWER ROADS. BIGGER HORIZONS.",
    "intro": "Make the approach part of your trip. A Guwahati to Tawang plan should prioritise manageable driving days and reliable overnight stops.",
    "sections": {
      "Shape your route": "Outline the journey through Bomdila and Dirang, then review the current route with local operators. Do not schedule arrival times from map estimates alone.",
      "Conditions, permissions and limitations": "High-elevation weather and road works can affect access. Check official advisories before departure and again before mountain sections. Confirm the route your rental agreement allows.",
      "Build a flexible itinerary": "Allow time to rest in Dirang and Tawang. Treat Sela, local lake visits and restricted border-area excursions as condition-dependent rather than guaranteed inclusions.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "guwahati-to-shillong-road-trip": {
    "title": "Guwahati to Shillong road-trip guide",
    "kicker": "A CHANGE OF PACE",
    "intro": "A Shillong journey can be a relaxed short break or the start of a longer Meghalaya itinerary. Build your plan around your arrival time, luggage and preferred pace.",
    "sections": {
      "Shape your route": "Discuss the Guwahati → Umiam → Shillong corridor. Decide whether to stay in Shillong before extending toward Sohra or the Dawki side of Meghalaya.",
      "Conditions, permissions and limitations": "City congestion, rain and mist can add time. Use daylight for unfamiliar roads and avoid relying on a fixed transfer duration. Check current weather and local traffic guidance.",
      "Build a flexible itinerary": "Choose accommodation with confirmed parking. Keep Umiam or Laitlum as planned stops rather than squeezing them into a late arrival day.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "sela-pass-travel-guide": {
    "title": "Sela Pass travel planning",
    "kicker": "HIGH COUNTRY, CAREFULLY PLANNED",
    "intro": "Sela is part of a high-elevation landscape associated with the Tawang approach. Plan visits around current road access and weather.",
    "sections": {
      "Shape your route": "Confirm the current through route and any sightseeing detour with local authorities or your accommodation. Do not assume a particular pass road is open simply because a map shows it.",
      "Conditions, permissions and limitations": "Snow, ice, low visibility and altitude may affect safe travel. Follow closures and advisories; vehicle category alone does not establish safe access.",
      "Build a flexible itinerary": "Sela Lake visits need appropriate conditions and safe stopping. Keep warm layers accessible and seek qualified medical advice if you have altitude-related concerns.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "mago-arunachal-pradesh-guide": {
    "title": "Mago: access-first travel planning",
    "kicker": "THE REMOTE NORTHEAST",
    "intro": "A remote-area journey should begin with verified access, rather than a vehicle booking. Mago requires destination-specific local planning.",
    "sections": {
      "Shape your route": "Ask the relevant district authorities and experienced local operators to confirm the route, accommodation, communications and whether any proposed leg is open to visitors.",
      "Conditions, permissions and limitations": "Do not assume a self-drive vehicle may enter. Permissions, guide requirements and onward transport must be checked for the exact itinerary and traveller nationality.",
      "Build a flexible itinerary": "Gongkarla Lake is not offered as a confirmed excursion here. Its location, route, visitor eligibility and imagery require verification before an itinerary can be published.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "bumla-pass-travel-guide": {
    "title": "Bumla Pass: permissions before plans",
    "kicker": "LOCAL ACCESS MATTERS",
    "intro": "Treat a Bumla visit as a separately planned local excursion from Tawang. It is not an automatic inclusion in a rental-car itinerary.",
    "sections": {
      "Shape your route": "Consult current Tawang district guidance and a permitted local operator before making a booking. Confirm the required paperwork, transport and weather-related access.",
      "Conditions, permissions and limitations": "A visitor entry permit for Arunachal does not by itself establish access to a restricted border area. Do not take a self-drive rental beyond its approved route.",
      "Build a flexible itinerary": "Keep your itinerary flexible. Madhuri Lake and other nearby stops also need current access checks; do not assume every attraction can be combined on one day.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "anini-road-trip-guide": {
    "title": "Anini road-trip planning",
    "kicker": "MAKE ROOM FOR THE JOURNEY",
    "intro": "Anini belongs to a separate eastern Arunachal journey. Avoid treating it as a short extension of a Tawang holiday.",
    "sections": {
      "Shape your route": "Plan the approach and overnight stops with local operators. Confirm the current roads, fuel stops, accommodation and communication arrangements for every leg.",
      "Conditions, permissions and limitations": "Check entry permits, district guidance and vehicle permission for your exact itinerary. Remote travel needs spare time and a practical alternative if conditions change.",
      "Build a flexible itinerary": "Choose a vehicle based on the verified route and luggage needs. Share the complete plan with SAAFAAR before asking for a quote.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "hornbill-festival-car-rental-guwahati": {
    "title": "Hornbill Festival travel from Guwahati",
    "kicker": "CULTURE. COMMUNITY. CONNECTION.",
    "intro": "Plan a Nagaland journey around the official Hornbill Festival programme and your confirmed accommodation. Kisama Heritage Village is a key festival setting near Kohima.",
    "sections": {
      "Shape your route": "Discuss a Guwahati-to-Kohima journey and onward local transport with your rental team. Confirm accommodation, parking and festival-day transfers before leaving.",
      "Conditions, permissions and limitations": "Check the current official festival calendar and Nagaland entry requirements for your nationality. Dates, events and access arrangements are not guaranteed by this website.",
      "Build a flexible itinerary": "Book a manageable stay around Kohima, respect photography guidance and leave time for local traffic. Ask whether festival-area access is better handled by local transport.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "foreign-tourist-car-rental-guide": {
    "title": "Self-drive enquiries for international visitors",
    "kicker": "PLAN YOUR DOCUMENTS FIRST",
    "intro": "International visitors should confirm driver eligibility, accepted documents and route permissions with SAAFAAR before arranging a self-drive rental.",
    "sections": {
      "Shape your route": "Share your nationality, licence issuing country, travel dates and proposed route through a secure agreed channel. Do not send identity-document scans in a public enquiry form.",
      "Conditions, permissions and limitations": "The accepted licence, international driving permit, minimum age, insurance conditions and security deposit need written confirmation. This site does not assert eligibility for every visitor.",
      "Build a flexible itinerary": "State and restricted-area permissions may differ by nationality and destination. Consult official government information and obtain current guidance before booking.",
      "Before you book": "Confirm permitted routes, the actual vehicle, written charges, rental terms and overnight plans. Road access is not guaranteed by a booking. Contact SAAFAAR with your travel dates and party size for a route-aware enquiry.",
      "Vehicle, stays and safety": "Choose the actual vehicle around passengers, luggage and the staff-approved route. Confirm parking with each stay, allow daylight for unfamiliar sections and plan fuel and communication stops with local guidance. Do not enter a closed road or continue through conditions beyond your experience.",
      "Questions to settle before departure": "Is the full route permitted for this vehicle? Are visitor or local-area permissions needed? Which planned stops require walking or local transport? What is the alternative if weather changes? Record the answers with your accommodation, local operator and rental team before setting out."
    },
    "kind": "guide"
  },
  "about": {
    "title": "A little more freedom. A little more SAAFAAR.",
    "kicker": "SAAFAAR HOLIDAYS",
    "intro": "SAAFAAR is an independent self-drive car rental brand focused on Guwahati and journeys through Northeast India.",
    "sections": {
      "Travel, on your terms": "Choose where to pause, when to set out and which road to explore next. Our enquiry process starts with your dates, group and proposed route so the vehicle and arrangements can be checked together.",
      "Clarity before commitment": "We publish approved listing information and distinguish an enquiry, a quotation and a confirmed booking. Prices, deposits, pickup services and route permissions should be agreed before travel.",
      "Speak to SAAFAAR": "Call +91 9181628882 or send a WhatsApp enquiry. We do not publish unverified addresses, reviews, fleet claims or operating-history claims."
    },
    "kind": "info"
  },
  "faq": {
    "title": "Good questions. Clear next steps.",
    "kicker": "BEFORE YOU SET OFF",
    "intro": "A few things to know while planning a self-drive journey with SAAFAAR.",
    "sections": {
      "Does an enquiry reserve a vehicle?": "No. A request is reviewed by staff. A booking is confirmed only after availability, quotation and any required verified payment have been approved.",
      "Can I choose airport or station pickup?": "You can request it. The meeting point, timing, delivery availability and fees must be confirmed by staff.",
      "Can I drive to every destination?": "No universal route permission is implied. Tell staff your complete itinerary. Restricted areas may require separate permission or local transport.",
      "Does submitting a UTR confirm payment?": "No. It records a transaction reference for manual checking. Payment stays pending until staff verify receipt.",
      "Where are the cancellation and deposit rules?": "The applicable approved written terms must be supplied before booking. Unapproved policy pages remain marked as pending."
    },
    "kind": "info"
  },
  "rental-terms": {
    "title": "Rental terms",
    "kicker": "BUSINESS APPROVAL PENDING",
    "intro": "The final business-approved policy has not yet been supplied. Do not make a payment or accept a rental without reviewing the applicable written terms.",
    "sections": {
      "Request the current written terms": "Contact SAAFAAR on +91 9181628882. This page does not create a cancellation, deposit, insurance or driver-eligibility policy."
    },
    "kind": "policy"
  },
  "cancellation-refund-policy": {
    "title": "Cancellation and refund policy",
    "kicker": "BUSINESS APPROVAL PENDING",
    "intro": "The final business-approved policy has not yet been supplied. Do not make a payment or accept a rental without reviewing the applicable written terms.",
    "sections": {
      "Request the current written terms": "Contact SAAFAAR on +91 9181628882. This page does not create a cancellation, deposit, insurance or driver-eligibility policy."
    },
    "kind": "policy"
  },
  "privacy-policy": {
    "title": "Privacy policy",
    "kicker": "BUSINESS APPROVAL PENDING",
    "intro": "The final business-approved policy has not yet been supplied. Do not make a payment or accept a rental without reviewing the applicable written terms.",
    "sections": {
      "Request the current written terms": "Contact SAAFAAR on +91 9181628882. This page does not create a cancellation, deposit, insurance or driver-eligibility policy."
    },
    "kind": "policy"
  }
}
JSON, true);
