<?php
header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');header('X-Robots-Tag: noindex, nofollow');
if($path==='/api/csrf/'){echo json_encode(['csrf'=>csrf()]);return;}
if($path==='/api/vehicles/'){rate_limit('api',120,60);$s=sql('SELECT id,slug,make,model,model_year,transmission,fuel,seats,category,daily_paise,included_km FROM vehicles WHERE approved=1 AND active=1 ORDER BY id');echo json_encode(['vehicles'=>$s->fetchAll(),'availability'=>'Select dates for a reservation and blackout check.']);return;}
if(in_array($path,['/api/availability/','/api/quote/'],true)){rate_limit('api',120,60);[$s,$e]=period($_GET);$id=(int)($_GET['vehicle_id']??0);$v=sql('SELECT * FROM vehicles WHERE id=? AND approved=1 AND active=1',[$id])->fetch();if(!$v)fail('Vehicle not found.',404);$ok=available($id,$s->format('Y-m-d H:i:s'),$e->format('Y-m-d H:i:s'));$quote=quote($v,$s,$e,(int)($_GET['pickup_location']??0),(int)($_GET['return_location']??0),(string)($_GET['promo_code']??''));echo json_encode(['eligible'=>$ok,'quote'=>$quote,'reservation_confirmed'=>false,'timezone'=>'Asia/Kolkata']);return;}
fail('API endpoint not found.',404);
