<?php
declare(strict_types=1);
date_default_timezone_set('Asia/Kolkata');
$configFile = dirname(__DIR__).'/config/config.php';
$cfg = is_file($configFile) ? require $configFile : require dirname(__DIR__).'/config/config.example.php';
ini_set('display_errors','0');
ini_set('session.use_strict_mode','1');
$sessionPath=dirname(__DIR__).'/storage/private/sessions';
if(!is_dir($sessionPath)&&!mkdir($sessionPath,0700,true))throw new RuntimeException('Cannot create private session directory.');
session_save_path($sessionPath);
session_name('saafaar_session');
session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off','samesite'=>'Lax','path'=>'/']);
if (PHP_SAPI!=='cli') {session_start();header('Cache-Control: no-store');}
header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: DENY'); header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
$analyticsConfigured=preg_match('/^G-[A-Z0-9]+$/D',$cfg['ga4_id']??'')===1;
$scriptAnalytics=$analyticsConfigured?' https://www.googletagmanager.com':'';
$connectAnalytics=$analyticsConfigured?' https://www.google-analytics.com https://region1.google-analytics.com':'';
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'$scriptAnalytics; connect-src 'self'$connectAnalytics; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
set_exception_handler(function(Throwable $e) { if(db_safe_rollback()){} error_log('SAAFAAR '.get_class($e).': '.$e->getMessage()); if(PHP_SAPI==='cli'){fwrite(STDERR,"Operation failed. Check the private server log.\n");exit(1);} http_response_code(500); if(str_starts_with($_SERVER['REQUEST_URI']??'','/api/')) {header('Content-Type: application/json'); echo json_encode(['error'=>'Service temporarily unavailable. Please contact SAAFAAR.']);} else {echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Service unavailable | SAAFAAR</title><h1>We could not complete that request</h1><p>Please try again or call +91 9181628882.</p><a href="/">Return home</a></html>';} });
function booking_enabled(): bool { global $cfg; $p=require __DIR__.'/policies.php'; return !empty($cfg['approved_terms_version'])&&!empty($p['rental-terms'])&&!empty($p['privacy-policy']); }
function e(mixed $v): string {return htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function db(): PDO {static $db=null; global $cfg; if(!$db) {$db=new PDO($cfg['db_dsn'],$cfg['db_user'],$cfg['db_password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); $db->exec("SET time_zone = '+05:30'");}return $db;}
function db_safe_rollback(): bool {try{if(db()->inTransaction()) db()->rollBack();}catch(Throwable $e){} return true;}
function sql(string $q,array $p=[]): PDOStatement {$s=db()->prepare($q);$s->execute($p);return $s;}
function csrf(): string {return $_SESSION['csrf']??=bin2hex(random_bytes(32));}
function csrf_field(): string {return '<input type="hidden" name="csrf" value="'.e(csrf()).'">';}
function fail(string $m,int $code=422): never {http_response_code($code); if(str_starts_with($_SERVER['REQUEST_URI']??'','/api/')) {header('Content-Type: application/json');echo json_encode(['error'=>$m]);} else {require_once __DIR__.'/layout.php';page_start('Request needs attention','Please check the supplied information.',true);echo '<main class="wrap narrow section"><h1>One more thing</h1><p>'.e($m).'</p><a class="button" href="/">Return home</a></main>';page_end();}exit;}
function check_csrf(): void {if(!hash_equals(csrf(),(string)($_POST['csrf']??$_SERVER['HTTP_X_CSRF_TOKEN']??'')))fail('Your session expired. Reload the page and try again.',403);}
function redirect(string $url): never {header('Location: '.$url, true,303);exit;}
function money(?int $n): string {return $n===null?'Quote on request':'₹'.number_format($n/100,2);}
function rate_limit(string $scope,int $max=10,int $seconds=900):void {$k=hash('sha256',$scope.'|'.($_SERVER['REMOTE_ADDR']??'cli'));sql('INSERT INTO rate_limits(key_hash,attempts,window_start) VALUES(?,1,?) ON DUPLICATE KEY UPDATE attempts=IF(window_start < ?,1,attempts+1), window_start=IF(window_start < ?,VALUES(window_start),window_start)',[$k,time(),time()-$seconds,time()-$seconds]);$r=sql('SELECT attempts FROM rate_limits WHERE key_hash=?',[$k])->fetch();if($r['attempts']>$max)fail('Too many attempts. Please try again later.',429);}
function audit(string $a,?int $id=null,string $details=''):void {sql('INSERT INTO audit_logs(administrator_id,action,entity_id,details) VALUES(?,?,?,?)',[$_SESSION['admin']['id']??null,$a,$id,$details]);}
function admin(bool $owner=false): array {if(empty($_SESSION['admin']))redirect('/admin/login/');$current=sql('SELECT id,username,role,password_hash FROM administrators WHERE id=?',[$_SESSION['admin']['id']])->fetch();if(!$current||!hash_equals($_SESSION['admin']['fingerprint']??'',hash('sha256',$current['password_hash']))){unset($_SESSION['admin']);redirect('/admin/login/');}$_SESSION['admin']['role']=$current['role'];if(time()-($_SESSION['admin_time']??0)>1800){unset($_SESSION['admin']);redirect('/admin/login/');}$_SESSION['admin_time']=time();if($owner&&$_SESSION['admin']['role']!=='owner')fail('Owner permission required.',403);return $_SESSION['admin'];}
function text_input(string $k,int $max=200,bool $required=true):string {$v=trim((string)($_POST[$k]??''));if(($required&&$v==='')||mb_strlen($v)>$max)fail('Invalid '.str_replace('_',' ',$k).'.');return $v;}
function phone(string $v):string {$v=preg_replace('/[ ()-]/','',$v);if(!preg_match('/^\+?[0-9]{10,15}$/D',$v))fail('Enter a valid contact phone number.');return $v;}
if(PHP_SAPI!=='cli'){foreach([$_GET,$_POST] as $input){foreach($input as $key=>$value){if(is_array($value)&&$key!=='locations')fail('Invalid input structure.');}}}
require_once __DIR__.'/booking.php';
