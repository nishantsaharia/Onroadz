# Owner input and launch gates

Only the master requirements document was received. The following cannot be completed accurately without owner assets or decisions. No invented substitutes are presented as verified facts.

## Required assets
- Official approved logo source, light/dark derivatives, app/social usage approval.
- Vehicle archive plus exact photograph-to-vehicle mapping, copyright/usage authorization and approved inventory.
- Destination originals with confirmed location identities. Mago/Gongkarla require explicit verification.

## Commercial and legal
- Vehicle models, variants, years, fuel, transmission, seating, equipment, luggage, ownership/availability statements and restrictions.
- Rate schedule, exact charging-duration rule, minimum rental, deposits, included kilometres, excess-km rate, fees, tax treatment, discounts and advance percentage.
- Driver age, licences, international visitor documents, insurance/exclusions, ID checks, fuel/return inspection, interstate and restricted-area permissions.
- Rental agreement, cancellation/refund terms, liability/privacy/retention and customer-data handling approval. No legal boilerplate creates policy here.
- Pickup/delivery services, location fees, waiting charges, flight-delay process, service/support hours.

## Payments and contact
- Independently verify UPI ID 9181628882@pz, payee name, receiving account, collection authority and settlement process. Supply no banking secrets in chat.
- An agreed manual verification/refund procedure and staff responsibilities.
- Approved public email and office address if applicable. Neither is invented. Phone and WhatsApp use the supplied +91 9181628882.

## Editorial, SEO and hosting
- Current source review for travel routes, permits, local transport and festival programme. Approve destination content individually.
- Domain hosting, TLS, independent database, admin credentials and production acceptance tests.
- Real Search Console verification, legitimate eligible Business Profile and optional GA4 measurement ID with approved consent/privacy handling.

Do not call this package a fully launch-ready business website until these gates are resolved. The codebase can be installed and tested on staging immediately; public booking/payment activation is deliberately blocked by missing approvals.
