# cPanel installation

## 1. Prepare the hosting account
- Select PHP 8.2+ (tested here on PHP 8.4.24) and enable pdo_mysql, mbstring, gd/WebP, session, fileinfo, JSON and OpenSSL. Use a supported patched release. MySQL 8+ or MariaDB 10.6+ with InnoDB is required.
- In Domains, configure saafaar.in and issue its AutoSSL certificate. Verify HTTPS before accepting personal information.
- Extract the ZIP to a private directory such as `/home/CPANELUSER/saafaar/`. **Set the domain document root to `/home/CPANELUSER/saafaar/public`.** Only files inside `public/` are public.
- If the host forces `public_html`, ask it to set the document root correctly. Alternatively keep private directories alongside public_html, copy ONLY public's contents into public_html and adjust the require paths in index.php to the private project directory. Preserve the same directory layout used by app uploads and router paths or obtain a reviewed host-specific adaptation. Do not expose the full project and rely only on robots.txt. The latter alternative requires host-specific path edits and has not been tested here.

## 2. Install the independent database
- Create a new cPanel database and a new user for SAAFAAR. Grant that user privileges on that database only. Do not reuse Onroadz credentials or records.
- In phpMyAdmin, select the new empty database and import `database/schema.sql` once. It creates tables and four **inactive pickup-location options**, with no vehicles, customers, administrators or commercial policy.
- Installation SQL is not an incremental migration. Back up before any schema changes; do not reimport over live data.
- Copy `config/config.example.php` to `config/config.php` outside public. Set db_dsn (include utf8mb4), db_user and db_password. Keep this file private (0600 where the PHP user can read it). Never paste passwords into chat or commit them.
- PHP sets the database session timezone to +05:30. Application dates are entered and stored as IST DATETIME values. Money is integer INR paise.

## 3. Permissions and first administrator
- Make storage/private, storage/logs and public/uploads writable by the PHP account. Use least privilege; do not use 0777. Private sessions are created under storage/private/sessions with 0700, originals with 0600, public WebP derivatives with 0644.
- In cPanel Terminal/SSH, from the private project root, create a unique password of at least 14 characters using a local password manager. Run the following without putting it into command history:

```sh
read -r -s -p 'New administrator password: ' SAAFAAR_ADMIN_PASSWORD
printf '\n'
printf '%s' "$SAAFAAR_ADMIN_PASSWORD" | php bin/admin.php create YOUR_UNIQUE_USERNAME
unset SAAFAAR_ADMIN_PASSWORD
```

- Sign in at `/admin/login/`. There are no default credentials.
- For staff accounts, a verified owner/hosting administrator can create a unique hash with PHP's password_hash and insert a `staff` record via an authorized database console. The CLI create command creates owners only; do not share the owner's account.
- Recovery: use the same safe STDIN flow with `php bin/admin.php reset USERNAME`. Hosting access is the recovery trust boundary. Password changes invalidate the affected administrator's existing sessions on their next request. Never install a public reset script.

## 4. Business activation
- Obtain and publish approved rental/privacy/cancellation text in `app/policies.php` keyed by the matching URL slug. Values are plain text, escaped on output. Add the policy version in private config; record approval evidence.
- Agree the pricing rule. The implemented automatic rule is `daily_24h`: `ceil(actual IST elapsed seconds / 86400)` charged days, constrained by vehicle minimum hours. **Do not enable it unless the business approves it.** Alternative billing rules require a separate implementation and tests.
- Approve taxes, set tax_basis_points (100 basis points = 1%), and set tax_approved=true only after review. Taxes apply to rental + pickup/return fees − fixed promotion. Security deposit is separate, not added to rental total. Confirm tax treatment with a qualified adviser. This is not a GST invoice system.
- Set advance_basis_points only to the approved percentage. A zero advance creates no payment request. A positive advance is required to be verified before confirmation.
- Activate approved pickup services and fees in admin. Link the allowed locations to each vehicle. Current seeded options are request categories, not assertions that delivery operates.
- Add actual vehicles with verified model, year, transmission, seating, price, deposit, kilometres, extra-km rate, restrictions and photographs. Mark approved/active only after owner review. Unknown monetary fields stay null.
- Add maintenance blackouts before taking reservations. Blackouts cannot overlap an existing confirmed/active reservation. Pending booking requests do not create inventory holds.
- Apply fixed promotions in the owner-only Promotions screen. No codes are preinstalled.

## 5. Payments
- Confirm `9181628882@pz`, the intended payee name, authority to collect funds and settlement arrangement. Test with supported UPI apps and reconcile a small agreed transaction outside this build.
- Set verified_payee_name and payments_enabled=true only after verification. No payee name has been invented.
- Staff approve a server-generated quote, then create an advance request. Customer sees its amount/reference, UPI deep link and locally generated QR.
- UTR entry changes the payment to submitted only. Owner checks receiving-account statement and records verification evidence before marking verified. Confirmation is a separate action and rechecks inventory and payment.
- Rejected references can be resubmitted; verified references cannot be edited. Cancellation does not automatically refund funds. Refunds require an external verified process and approved policy.

## 6. Production review
- Replace every labelled photographic placeholder and all provisional branding. Read IMAGE-MANIFEST.md. Publish only approved imagery and mapped listings.
- Review travel guides against current official sources and set their individual approved flag only after editorial approval. Without approval they stay noindex.
- Set environment=production and correct base_url after launch checks. Apache's public/.htaccess enforces HTTPS and saafaar.in; no reliance on untrusted X-Forwarded-Proto. Have the host configure HTTPS server variables correctly if TLS terminates upstream.
- Run `php bin/preflight.php`. It intentionally fails while production gates are pending. Do not make its checks pass using invented data.
- Test pages, navigation, dates, quotes, a synthetic booking, payment verification, overlapping reservation rejection, uploads, robots, sitemap and secret protection on the actual host. Delete synthetic records and restore only approved inventory afterwards.
- Submit `/sitemap.xml` in Search Console only after the intended pages are indexable. There is no physical sitemap.xml/robots.txt to become stale; both are served by the front controller.
