# Organic search report
Period: ______  Previous comparable period: ______  Prepared by: ______

| Metric | Current | Previous | Source / checked date | Verification status |
|---|---|---|---|---|
| Indexed canonical pages | Unavailable | Unavailable | Search Console | Not connected |
| Sitemap status | Unavailable | Unavailable | Search Console | Not connected |
| Organic impressions / clicks | Unavailable | Unavailable | Search Console | Not connected |
| Average position / CTR | Unavailable | Unavailable | Search Console | Not connected |
| Main query / top landing pages | Unavailable | Unavailable | Search Console export | Not connected |
| Organic WhatsApp enquiries | Unavailable | Unavailable | Consented analytics + verified attribution | Not measured |
| Organic booking requests | Unavailable | Unavailable | Verified attribution + booking records | Not measured |
| Confirmed booking conversion | Unavailable | Unavailable | Verified confirmed records / agreed denominator | Not measured |
| Mobile LCP / INP / CLS | Unavailable | Unavailable | CrUX / real-user data | Not measured |
| Broken links / redirects | Unavailable | Unavailable | Production crawl | Not deployed |
| Canonical / structured-data warnings | Unavailable | Unavailable | GSC / validators | Not externally checked |

Observations supported by evidence: ______
Unavailable data and reason: ______
Changes made, expected effect and review date: ______
Next actions, owner and priority: ______

Never replace unavailable values with invented zeros or performance claims. Local integration tests do not establish production SEO performance.
