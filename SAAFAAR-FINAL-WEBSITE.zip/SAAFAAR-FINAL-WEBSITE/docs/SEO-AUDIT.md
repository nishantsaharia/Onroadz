# Technical SEO audit and launch checklist

Implemented: server-rendered HTML with lang, viewport and UTF-8; unique page titles and descriptions; canonical paths on saafaar.in; Open Graph and Twitter card; Organization JSON-LD with supplied phone; visible breadcrumbs and matching BreadcrumbList; meaningful heading hierarchy; crawlable internal links; dynamic approved vehicle sitemap; private-page robots/no-store; HTTP 404; host/HTTPS/trailing-slash rewrite source; public static compression/cache configuration; lazy gallery/card images with dimensions; system fonts; reduced-motion CSS; local assets.

No fabricated ratings, address, languages, fleet counts, prices, reviews, business history, event dates, author identity or lastmod timestamps are emitted. Vehicle offers/availability schema is intentionally omitted until verified public inventory and offer semantics warrant it. No Google rich-result or ranking claims.

## Indexation gates
- Entire staging environment defaults to noindex/nofollow and robots Disallow:/.
- Admin, APIs, actions, booking management and confirmations stay private/noindex.
- Filter/query variants are noindex and canonicalize to their base page.
- Unapproved legal/travel pages stay noindex. Approved travel guides must carry approved=true in app/content.php. Final policy text is stored in app/policies.php.
- Sitemap emits public approved routes and active/approved vehicle slugs dynamically; no private URLs, fake dates or arbitrary filtered URLs. Staging sitemap is not for submission.

## Per-page review template
| URL | Owner/content approval | 200 | Unique title/description | Canonical | Indexable | Image identity/ALT | Internal links | Schema validator | Mobile review |
|---|---|---|---|---|---|---|---|---|---|
| / | Pending assets | Local 200 | Implemented | / | Staging no | Pending | Local crawl | Not externally validated | Chromium checked |
| /cars/ | Pending inventory | Local 200 | Implemented | /cars/ | Staging no | Pending | Local crawl | N/A | Chromium checked |
| Commercial routes | Copy included | Local crawl | Implemented | Self | Staging no | Pending | Local crawl | Not externally validated | Responsive CSS |
| Travel guides | Review pending | Local crawl | Implemented | Self | No until approval | Pending | Local crawl | Conservative Organization/breadcrumb only | Responsive CSS |

## Launch actions
1. Replace placeholders with approved responsive derivatives and accurate alt text. Reassess LCP after real images are installed.
2. Verify Apache redirects and HTTP status on production; verify no private source can be fetched. Confirm certificate and canonical host.
3. Review policy and editorial gates. Set production intentionally, then crawl sitemap and every indexable URL. Do not submit staging.
4. Validate live pages with Rich Results Test/Schema Markup Validator and Search Console URL Inspection. No external validator was used during this build.
5. Create Search Console domain property, add the supplied DNS TXT record at the actual DNS provider, verify, submit sitemap, inspect representative pages and monitor Page indexing/canonical selection.
6. If eligible, create one accurate Business Profile using the real business/service-area details. Do not invent an office or duplicate locations. Keep phone/name consistent and seek authentic customer feedback.
7. Add a genuine GA4 ID only after privacy review. Consent defaults off; no PII or private URLs are sent by the implemented script. Test in DebugView with a consented synthetic journey.
8. Run Lighthouse on production/mobile and record actual LCP/INP/CLS from field data when sufficient traffic exists. Targets (LCP ≤2.5s, INP ≤200ms, CLS ≤0.1) are objectives, not results.
