# 60-day organic search implementation plan

No rankings are guaranteed. Start the day count at an approved production launch, not at this code delivery. Each milestone needs an owner, evidence link and actual measurement.

| Period | Work | Acceptance evidence |
|---|---|---|
| Days 1–7 | Finish assets/business gates; HTTPS/canonical redirects; mobile checks; crawl indexable routes; validate schema; verify Search Console; submit dynamic sitemap; baseline performance | Crawl export, live headers, verification record, sitemap submitted status, measured Lighthouse report |
| Days 8–15 | Improve the primary Guwahati commercial page, airport handover guidance, automatic/SUV/seven-seat content; approve inventory and rates; add real gallery images; improve links between service and catalogue | Owner approvals, no duplicate query pages, enquiry journey test, GSC coverage |
| Days 16–30 | Review official current guidance; publish useful Meghalaya, Tawang, Arunachal, Mago and Hornbill content only when distinct/accurate; add original photographs and captions | Editorial source register, approval dates, image identity manifest, URL Inspection |
| Days 31–45 | Compare actual GSC query/page data; improve snippets on pages with impressions and weak CTR; seek legitimate local travel citations and partnerships; strengthen contextual links | Query comparisons with dates, genuine citations, updated titles/copy and test log |
| Days 46–60 | Compare equal windows; review organic enquiries and confirmed bookings using actual records; fix crawl/canonical/performance issues; refine successful pages and plan next 90 days | SEO report with verified/unavailable metrics clearly separated, prioritized roadmap |

## Operating cadence
Weekly: review indexing, sitemap errors, queries, landing pages and broken links. Record exact date ranges and data sources. Separate branded/non-branded queries and avoid reacting to very small samples. Monthly: verify travel guidance, real fleet rates and image performance. Track source-assisted enquiries carefully; a WhatsApp click is not a paid booking.

Never buy spam links, invent reviews, create doorway pages or promise first-page rankings in 30–60 days. Distinct intent and useful local information take precedence over producing more pages.
