# Editorial verification register
The included travel copy is conservative planning guidance, not a statement of current access. No official permit rules, distances, driving durations, opening times or festival dates are asserted. All travel articles remain noindex pending current local editorial review. No live source research was performed in this build.

Before publication, verify and record the URL, date, relevant statement and reviewer using these official starting points (links are resources, not proof that a rule was checked):
- https://arunachaltourism.com/
- https://tawang.nic.in/
- https://meghalayatourism.in/
- https://tourism.nagaland.gov.in/
- https://hornbillfestival.com/ (verify the current official event site)
- https://assamtourism.gov.in/
- https://indianvisaonline.gov.in/

Pending: Mago/Gongkarla route identity, border-area permissions, nationality-specific requirements, rental entry permissions, district advisories, event programme, local transport requirements. Approve each article in app/content.php by adding `approved: true` only after review. Record review evidence here. The general Northeast hub can link these guides, but staging is entirely noindex.
