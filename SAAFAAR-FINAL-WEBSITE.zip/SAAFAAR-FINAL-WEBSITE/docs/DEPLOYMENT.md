# Deployment and operations

The exact cPanel procedure is in INSTALLATION.md. No hosting login, production database or domain deployment was performed during this build.

## Production security checks
1. Confirm document root is public/, Apache mod_rewrite is active and AllowOverride permits the supplied file. Verify project-root files, config, schema, storage, source originals and tests cannot be fetched over HTTP.
2. Verify the certificate and HTTP/non-www redirect using actual host responses; test HTTP, www and query-string preservation. A reverse proxy must correctly populate HTTPS; do not blindly trust a client-controlled forwarding header.
3. Check file ownership, PHP display_errors=Off and hosting error logs. Exclude personal information from application error messages. Protect host logs and backup archives.
4. Restrict database privileges to the independent SAAFAAR database. Maintain encrypted off-site backups and test restoration. Rotate credentials after installation; update private config, verify connection and invalidate old DB credentials.
5. Set account-level PHP request/upload limits consistent with the application's 8 MB image limit. Use modern browser-compatible TLS. Rate limiting keys use REMOTE_ADDR, never spoofable forwarded headers; configure a trusted proxy at the hosting layer if needed.
6. Cookie security follows the actual HTTPS connection. Private responses send no-store. Verify browser Secure/HttpOnly/SameSite=Lax on production. Sessions idle-expire for staff after 30 minutes.
7. Do not put `storage` or config into a CDN. PWA caching allowlists only public CSS/icons; online HTML is network-only and private offline content is never stored.
8. Inspect outbound WhatsApp URLs: they contain the user's validated booking summary only after deliberate action. Booking access keys are never included. They must remain private.

## Booking operation
Requested → quoted → confirmed → active → completed. Requested/quoted can be rejected/cancelled; confirmed can be cancelled. Active rentals can be completed. Closed records are not reopened by the generic status action. Cancellation requests do not automatically change status or promise a refund. Only staff confirmation reserves dates. Dates are half-open [pickup,return), so a return exactly at another pickup does not overlap.

Quotes are snapshots. Staff approval recomputes against current approved rates. Once a payment request exists the quote cannot be rewritten; resolve the request with the customer instead. UTRs are unique. No API/webhook from a bank is connected. Receipt verification requires an owner; operational staff cannot verify money or edit vehicle listings. Audit records capture critical changes.

## Reports and retention
Owner CSV export includes booking references, customer contact and schedules. Treat exports as personal data, restrict access and delete when no longer needed. CSV spreadsheet formulas are prefixed to prevent execution. Dashboard verified receipts are not an accounting ledger or tax report.

Agree retention and privacy procedures before launch. Use secure hosting tools to fulfil verified data requests and record the decision. Expired booking links deny access; booking data is not auto-deleted. Rate-limit records should be pruned periodically (e.g. remove entries older than 30 days). Expired PHP sessions can be removed through a reviewed hosting cron. Establish backup, session and original-image retention policies.

## Recovery and rollback
Before release, back up database plus uploaded derivatives and private originals separately with correct permissions. Restore into an isolated staging account and validate preflight and representative transactions before redirecting traffic. Do not restore stale availability over a live database without reconciling bookings/payments. Do not reset real customer data with test scripts.

## External services
No email address is supplied; no email/SMS/OTP or password-reset mail is sent. Staff notification is the admin dashboard and optional user-initiated WhatsApp handoff. Monitor dashboard requests operationally. No bank verification API, payment gateway, identity verification provider or rental insurance integration is configured. These are separate integrations, not fabricated live connections.

On later releases, bump the service-worker static cache version when changing cache-listed assets. If using a separate staging hostname on Apache, use a reviewed staging-specific rewrite configuration; the supplied production file intentionally canonicalizes to saafaar.in.
