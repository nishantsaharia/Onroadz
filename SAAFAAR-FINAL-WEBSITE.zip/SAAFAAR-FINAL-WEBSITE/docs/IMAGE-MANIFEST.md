# Asset audit
Received: requirements text only. No vehicle ZIP, destination ZIP, reference-site ZIP or approved logo artwork was supplied.

| Asset | Current state | Required action |
|---|---|---|
| Official logo | Absent | Supply approved artwork; replace temporary text wordmark and provisional S icons |
| Vehicle photographs | Absent | Supply originals and owner-approved model/variant/year/view mapping |
| Destination photographs | Absent | Supply originals with confirmed place identities |
| Hero | Original abstract SVG route illustration, explicitly labelled placeholder | Replace with approved photographic asset |
| Destination cards | CSS contour artwork, explicitly labelled placeholders | Replace with verified originals |
| OG and app icons | Original provisional typography; no claim of approved logo | Rebuild from approved artwork |

No stock photographs, copied customer data, invented vehicles or claimed reviews are included. `public/assets/media/route-art.svg` is original decorative artwork, not a representation of a particular road or car.

The admin uploader archives originals outside public, validates image type/dimensions, decodes and re-encodes WebP, strips metadata, generates a random public filename and stores explicit alt text. Only owners may upload. Supply accurate mapping before publication. Multi-image galleries are supported and reordered in admin.

For batch originals, extract archives to a private directory using a path-safe extractor, inspect every file and folder, review `approved-images.example.json`, then run `bin/prepare-images.py`. It generates responsive WebP sizes and a review register for unmapped files without guessing identities. Originals are hashed and archived privately. AVIF generation is optional and not included. Connect processed variants to templates with matching width/height/srcset only after review; do not publish an unassociated photograph.

The owner admin UI requires at least one uploaded mapped image before activating an approved listing. First save the vehicle inactive, upload the correct photographs, then publish. Direct SQL is an administrative trust boundary and must not bypass owner review.
