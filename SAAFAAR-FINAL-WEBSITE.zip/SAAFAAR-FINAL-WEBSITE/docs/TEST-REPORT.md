# Validation report

Build date: 4 November 2026 (IST). Tests used a local isolated MariaDB database, synthetic labelled records and randomly generated temporary credentials. No production service was contacted for payments or bookings.

## Environment
PHP 8.4.24 CLI development server; MariaDB 11.8.6; Chromium via Playwright; Python 3; Linux. No Node/Composer runtime dependency is required by the delivered application. PHP/MariaDB packages were downloaded using signed Debian indexes with verification enabled and extracted to a temporary test runtime because root installation was unavailable.

## Passed
- PHP syntax checks for all delivered PHP files; JavaScript syntax checks for application scripts and service worker.
- Schema installation on a fresh independent database, including constraints and indexes.
- **71 integration checks, 0 failed in the final run.** Full result list below.
- Separate concurrent-process test: two competing overlapping confirmations yielded exactly one committed reservation. Regression fix ensures the availability read occurs after acquiring the per-vehicle lock, avoiding an earlier repeatable-read snapshot.
- Chromium: owner login, server quote preview, customer request submission, staff quotation approval, payment request creation and local dynamic UPI QR rendering. No page JavaScript errors in this flow.
- Homepage and booking screen at 390px width: no horizontal overflow. Mobile menu opens and closes; desktop at 1440px renders.
- Internal crawl: **46 resources, 38 HTML pages, 0 failures**; canonical presence and single H1 verified for crawled HTML. This is a staging crawl, not a Google index report.
- UTR remains submitted/pending until a separate owner verification action; verified payment alone does not confirm a booking.

## Issues found and corrected during testing
Private session path was made writable; DB session timezone initialization was moved inside initial connection creation so it does not overwrite lastInsertId; a concurrent-confirmation snapshot bug was fixed; monetary validation no longer requires the optional ctype extension. The suite was rerun after corrections.

## Not tested / requires external acceptance
Actual cPanel/Apache rewrites, TLS certificate/cookie behaviour, supported PHP 8.2 hosting variants, MySQL 8 specifically, Safari/iPhone/Android physical devices, production load/penetration testing, live UPI apps/receiving-account reconciliation, refunds, email/OTP delivery, external schema validators, Google Search Console/Business Profile, GA4 transmission, Lighthouse and field Core Web Vitals. None are claimed passed. There is no live payment gateway or bank verification API.

## Business gates remain pending
Official logo, real vehicle/destination photographs, verified inventory/rates/deposits, approved policies/eligibility/route terms, receiving account/payee verification and current travel editorial source review. The default staging configuration is deliberately noindex and disables online booking/payment activation. No fake approvals, production inventory or admin credentials are bundled.

## Reproduce backend checks
Use a **disposable project copy**, an empty database literally named saafaar_test, an otherwise default private config pointing to it, and the local PHP server. Never run test scripts against production. Import schema.sql once into the new test DB. The test script temporarily changes business gates in the disposable copy and restores files in finally, but retains synthetic DB records and synthetic uploaded files for inspection. Recreate only the isolated test DB before another full run.

```sh
PHP_BIN=php TEST_BASE_URL=http://127.0.0.1:8088 python3 tests/integration.py
PHP_BIN=php python3 tests/concurrency.py
```

Concurrency test runs once after a fresh fixture run; repeated runs count all existing SF-RACE records and require cleanup of those synthetic records or a fresh test DB. Test fixtures are not installation seeds and are never imported by the production schema.

## Final integration output

```text
PASS Homepage renders
PASS Unknown page is 404
PASS CSRF rejects mutation
PASS Booking blocked without business approvals
PASS Unauthenticated staff route protected
PASS Private configuration not publicly served
PASS Owner login
PASS Staff login
PASS Staff cannot change pickup approvals
PASS Staff cannot export personal records
PASS SQL injection login rejected
PASS Approved vehicle visible
PASS Transmission filter excludes non-matching
PASS Seven-seat filter matches
PASS Budget filter works
PASS Array query rejected
PASS Server rounds approved 25-hour rental to 2 charging days
PASS Server total includes two location fees
PASS Approved advance calculated in paise
PASS Server rejects inverted dates
PASS Booking request created
PASS Customer output escaped
PASS Client price tampering ignored
PASS Request is not confirmed
PASS Reference alone does not expose booking
PASS Valid private key permits lookup
PASS Access key shown only once
PASS Second request can coexist before confirmation
PASS Cannot confirm without approved quote
PASS Owner approves quote
PASS Advance payment must be verified first
PASS Staff creates payment request
PASS Customer receives UPI request
PASS Customer submits UTR
PASS UTR submission stays pending
PASS Pending UTR cannot confirm booking
PASS Staff role cannot verify receipt
PASS Owner must acknowledge bank verification
PASS Owner records verified receipt
PASS Verified receipt alone does not confirm
PASS Owner confirms after verified advance
PASS Confirmed booking blocks overlapping quote availability
PASS Competing quote can be reviewed
PASS Overlapping confirmation rejected
PASS Owner creates maintenance blackout
PASS Blackout excludes availability
PASS Adjacent half-open intervals do not overlap
PASS Customer cancellation request recorded
PASS Cancellation request does not cancel automatically
PASS CSV export works
PASS Private response is no-store
PASS Security headers present
PASS Audit log renders
PASS Owner can create approved promotion
PASS Approved discount reduces server quote
PASS Unknown promo is rejected
PASS Disguised executable upload rejected
PASS Staff cannot upload images
PASS Owner image upload re-encodes successfully
PASS Public derivative is WebP
PASS Owner edits approved listing with mapped photograph
PASS Listing notes are HTML escaped
PASS New listing cannot publish without actual photo
PASS Admin page /admin/
PASS Admin page /admin/vehicles/
PASS Admin page /admin/vehicles/?edit=1
PASS Admin page /admin/locations/
PASS Admin page /admin/bookings/
PASS Admin page /admin/enquiries/
PASS Admin page /admin/promotions/
PASS Login throttling returns 429
{"passed": 71, "failed": 0}
```

## Hosting-startup update validation

After the reported live HTTP 500, startup handling was revised and tested locally on 4 November 2026. Eleven HTTP startup checks passed: full default layout, independent diagnostic, noindex/no-store and no path disclosure, public-only upload, unwritable storage, malformed config without credential disclosure, session-creation failure, and missing extensions. The 71-check integration suite and concurrent-booking test were rerun successfully. All updated PHP files pass syntax checks. `tests/startup.py` reproduces these cases in disposable copies without production credentials.

The live host's error log, web PHP version and document root have been requested but have not been supplied. No live-host root cause is claimed. Apache/cPanel and PHP 8.2 specifically have not been executed in this environment; local validation uses PHP 8.4.24.
