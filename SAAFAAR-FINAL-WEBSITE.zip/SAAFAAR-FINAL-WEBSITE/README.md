# SAAFAAR HOLIDAYS
## PHP/MySQL self-drive rental website — pre-launch source delivery

Built for https://saafaar.in using server-rendered PHP 8.2+, semantic HTML, CSS, vanilla JavaScript and MySQL 8+/MariaDB 10.6+. No Node build, Composer dependency, third-party QR API or copied Onroadz data is needed at runtime.

**Start with docs/INSTALLATION.md. Set the web document root to `public/`, not the project root.**

### Included
- Responsive public website, commercial/category pages, Northeast travel guides, enquiry form and genuine empty catalogue state.
- Owner-approved database listings; transmission/category/fuel/seats/budget/model filters; server-side date/location/minimum-duration eligibility.
- Multi-image galleries and owner-only image uploads with private originals and re-encoded WebP derivatives.
- Server quotations in integer paise; approved 24-hour charging rule; location fees, taxes, fixed promotional discounts, deposit and advance breakdown.
- Booking requests, independent staff quote approval, reservation conflict checks with per-vehicle row locking, maintenance blocks and status history.
- High-entropy private booking keys, hashed in storage, expiring 30 days after scheduled return; secure session lookup, cancellation/privacy requests.
- Separate owner/staff administration, manual receiving-account verification, UPI deep link/local dynamic QR, pending UTR submission and WhatsApp booking summary.
- Password hashing, CSRF, SQL prepared statements, output escaping, role checks, audit records, upload validation, throttling, security headers and private session files.
- Dynamic sitemap/robots, canonical metadata, Open Graph, Organization/breadcrumb JSON-LD, privacy-safe PWA fallback, optional consent-controlled GA4.
- SQL installation schema, CLI account creation/reset, preflight, test source, image preparation script, deployment, SEO plan and reporting templates.

### Required before launch
Only the requirements text was supplied. There is **no approved vehicle inventory, official logo, original photography, rate/deposit schedule, final legal text, route/driver eligibility rules or verified UPI payee name** in the delivery. The package deliberately does not invent them. Read docs/REQUIRED-APPROVALS.md and docs/IMPLEMENTATION-STATUS.md.

The provided icons and wordmark are provisional typography, explicitly not approved logo derivatives. Decorative illustrations are labelled placeholders. No vehicle is seeded in the installation schema. The public site defaults to staging/noindex; online requests require approved rental/privacy policy text and a version; pricing requires explicit rule/tax approval; payments require verified receiving-account configuration and an approved staff-created request.

This is a tested pre-launch codebase, **not a fully launch-approved site**. Do not remove approval gates to make an unfinished business configuration appear ready. No deployment, live payment, Google indexing, ranking or publication is claimed.

### Development
1. Create an independent local database and import database/schema.sql.
2. Copy config/config.example.php to config/config.php and configure its credentials privately.
3. PHP extensions: pdo_mysql, mbstring, gd with WebP, session, fileinfo; standard JSON/OpenSSL. Use PHP 8.2 or newer.
4. From the project root: `php -S 127.0.0.1:8080 -t public public/router.php`.
5. Open the local site in a development browser. PHP's built-in server is for development only.
6. Create your own unique administrator with bin/admin.php (installation guide). No account or password is bundled.
7. Use the existing checkout/workspace; a separate Git worktree is unnecessary.

### Structure
`public/` is the only web root. `app/`, `config/`, `database/`, `bin/`, `tests/`, `docs/` and `storage/` are private siblings. `.htaccess` at the project root denies HTTP access as a secondary safeguard; the correct document root is the primary protection. Never move private siblings into public_html indiscriminately.

`config/config.php`, uploaded originals, test data, sessions, database dumps and temporary passwords are excluded from the ZIP. Review `docs/TEST-REPORT.md` for actual validation and limitations.
