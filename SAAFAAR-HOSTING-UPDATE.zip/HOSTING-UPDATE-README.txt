SAAFAAR HOSTING STARTUP UPDATE

Back up the existing installation first. If your project uses the documented layout with app/config/storage beside public, extract this patch at the project root (the parent of public), preserving the app/ and public/ paths.

This patch contains no config.php, database schema, policies, uploads or customer records. It does not migrate or reset the database. Do not overwrite your private configuration or reimport SQL.

If you uploaded only public/* into public_html, first restore the complete project outside public_html and configure the domain document root to its public directory. The patch cannot recreate private files that were never uploaded.

To diagnose before patching, upload just public/hosting-check.php as hosting-check.php in the domain document root and visit /hosting-check.php. It is independent of the application and does not display credentials. Delete it after diagnosis.

If even the diagnostic returns HTTP 500, provide the latest cPanel Metrics > Errors or PHP/Apache error_log entry with secrets removed. Do not remove deny rules or set all permissions to 0777.

The live server error has not been identified without its log. This update improves startup handling; it does not prove the deployed site is fixed.
